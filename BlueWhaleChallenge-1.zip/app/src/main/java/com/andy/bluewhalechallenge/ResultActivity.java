package com.andy.bluewhalechallenge;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.util.Calendar;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import javax.microedition.khronos.opengles.GL;

/**
 * Created by STAR on 5/12/2017.
 */
public class ResultActivity extends AppCompatActivity {

    ProgressBar  m_pChecking;
    TextView m_tState;
    TextView m_tTimer;
    ImageView m_iCheckMark;
    ImageButton m_btnInfo;
    int dayTime = 86400;
    int hh = 0;
    int mm = 0;
    int ss = 0;

    Handler handler = new Handler();
    Runnable runnable = new Runnable() {
        public void run() {
            m_pChecking.setVisibility(View.INVISIBLE);
            m_iCheckMark.setVisibility(View.VISIBLE);
            m_tState.setText("ANSWER VERIFIED!");
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        //Create Admob Banner
  //      MobileAds.initialize(getApplicationContext(), "ca-app-pub-3940256099942544~3347511713");

        AdView adView = (AdView)findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable(){
                    @Override
                    public void run(){
                        m_tTimer = (TextView) findViewById(R.id.textView);
                        // task to be done every 1000 milliseconds
                        dayTime = dayTime - 1;
                        if (dayTime == 0){
                            Globals.task_number++;
                            if (Globals.task_number > 47){
                                Globals.task_number = 47;
                            }
                            startActivity(new Intent(ResultActivity.this, SelectActivity.class));
                            finish();
                        }
                        hh = dayTime/3600;
                        mm = (dayTime%3600)/60;
                        ss = (dayTime%3600)%60;
                        m_tTimer.setText(String.format("%02d:%02d:%02d", hh, mm, ss));
                    }
                });

            }
        }, 0, 1000);

        m_btnInfo = (ImageButton)findViewById(R.id.m_btnInfoID);
        m_btnInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(ResultActivity.this);
                dialog.setCancelable(false);
                dialog.setTitle("Blue Whale Challenge");
                dialog.setMessage("The rules are simple, there will be 50 tasks in total, you will be given a task every 24 hours after completing the previous task, to prove the task has been complete you are required to upload a picture or text which will then be verified for you to progress onto the next task." );
                dialog.setNegativeButton("Cancel ", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //Action for "Cancel".
                    }
                });
                final AlertDialog alert = dialog.create();
                alert.show();
            }
        });
        m_pChecking = (ProgressBar)findViewById(R.id.progress1);
        m_pChecking.setVisibility(View.VISIBLE);
        m_tState = (TextView)findViewById(R.id.m_sCheckingID);
        m_iCheckMark = (ImageView)findViewById(R.id.m_iCheckID);

        Random random = new Random();
        int rand_time = random.nextInt(6900000);
        int selected_time = rand_time + 300000;

        handler.postDelayed(runnable, selected_time);
        //Local Notification

//        Intent intent = new Intent(ResultActivity.this, MainActivity.class);
//        PendingIntent contentIntent = PendingIntent.getActivity(ResultActivity.this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
//
//        NotificationCompat.Builder b = new NotificationCompat.Builder(ResultActivity.this);
//
//        b.setAutoCancel(true)
//                .setDefaults(Notification.DEFAULT_ALL)
//                .setWhen(System.currentTimeMillis())
//                .setSmallIcon(R.drawable.check)
//                .setTicker("Hearty365")
//                .setContentTitle("Default notification")
//                .setContentText("Lorem ipsum dolor sit amet, consectetur adipiscing elit.")
//                .setDefaults(Notification.DEFAULT_LIGHTS| Notification.DEFAULT_SOUND)
//                .setContentIntent(contentIntent)
//                .setContentInfo("Info");
//
//
//        NotificationManager notificationManager = (NotificationManager) ResultActivity.this.getSystemService(Context.NOTIFICATION_SERVICE);
//        notificationManager.notify(1, b.build());
    }

    @Override
    public void onBackPressed(){

    }
}